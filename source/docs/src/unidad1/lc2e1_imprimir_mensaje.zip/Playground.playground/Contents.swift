// Miguel Oswaldo Escobar Cuellar
// 25-0729-2017
import Foundation

var str = "Hello, playground"
print(str)

var nombre = "Miguel Oswaldo"
print(nombre)
