// Hecho por: Miguel Oswaldo Escobar Cuellar
// Carnet: 25-0729-2017

var opcion = "D"

var valor1 = 1.5
var valor2 = 5.0
var result = 0.0

if (opcion == "S") {
    result = valor1 + valor2
}
if (opcion == "R") {
    result = valor1 - valor2
}
if (opcion == "M") {
    result = valor1 * valor2
}
if (opcion == "D") {
    if (valor2 != 0){
        result = valor1 / valor2
    } else {
        print("No se puede dividir entre cero.")
    }
}

print("El resultado de la operacion es: \(result)")
