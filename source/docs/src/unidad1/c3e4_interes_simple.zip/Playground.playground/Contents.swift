// Hecho por: Miguel Oswaldo Escobar Cuellar
// Carnet: 25-0729-2017

var I : Double = 0.0
var c : Double = 0.0
var i : Double = 0.0
var t : Double = 0.0


c = 5000.00
i = 12.0
t = 3.0
I = c * ( i / 100 ) * t 

print(I)