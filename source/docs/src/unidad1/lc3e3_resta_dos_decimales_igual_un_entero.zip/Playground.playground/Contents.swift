// Miguel Oswaldo Escobar Cuellar
// 25-0729-2017
import Foundation

var num1 = 9.5
var num2 = 2.1
var result = Int(num1 - num2)

print("\(num1) - \(num2) = \(result)")