// Miguel Oswaldo Escobar Cuellar
// 25-0729-2017
import Foundation

var num1 = 9
var num2 = 5
var result = num1 * num2

print("\(num1)*\(num2)=\(result)")