// Hecho por: Miguel Oswaldo Escobar Cuellar
// Carnet: 25-0729-2017

import Foundation

var numero : Int = 5

var valor1 = 4
var valor2 = 5

// Flujo de control
if (valor1 < valor2) { // Operadores logicos: <, >, ==, !=, <=, >=
    print("Si")
} else {
    print("No")
}