/*
    Hecho por: Miguel Oswaldo Escobar Cuellar
    Fecha: 31 de Julio 2021
*/

import Foundation

// Definicion de variables de manera explicita
var str = "Hola mundo!"

// Definicion de variables de manera implicita

var valor1:Int = 3
var valor2:Int = 4
var result:Int = 0

result = valor1 + valor2

print("La suma de \(valor1) mas \(valor2), es igual a: \(result)")
