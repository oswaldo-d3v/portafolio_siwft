// Hecho por: Miguel Oswaldo Escobar Cuellar
// Carnet: 25-0729-2017
import Foundation

var tabla = 5

for i in 1...10 {
  print("\(tabla)x\(i)=\(i*tabla)")
}
