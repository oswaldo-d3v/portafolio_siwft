// Miguel Oswaldo Escobar Cuellar
// 25-0729-2017
import Foundation

var num1 = 9.5
var cuadrado = num1 * num1
print("El cuadrado de \(num1), es: \(cuadrado))")