// Hecho por: Miguel Oswaldo Escobar Cuellar
// Carnet: 25-0729-2017
import Foundation

// Declaracion de una constante
let a = 0

var numeroUno = 2
var numeroDos = 3

var totalSuma = numeroUno + numeroDos

numeroUno = numeroUno + 1
numeroDos = numeroDos + 1

totalSuma = numeroUno + numeroDos

print("Total suma: \(totalSuma)")
