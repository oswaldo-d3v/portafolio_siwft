// Hecho por: Miguel Oswaldo Escobar Cuellar
// Carnet: 25-0729-2017

for i in 0...20 {
    print("Iteracion: \(i)")
}
