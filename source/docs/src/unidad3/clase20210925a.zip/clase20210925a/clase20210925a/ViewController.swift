//
// Nombre:
// Carnet:
//
//  ViewController.swift
//  clase20210925a
//
//  Created by Development on 9/25/21.
//  Copyright © 2021 Development. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    

    @IBOutlet weak var txtvalor1: UITextField!
    @IBOutlet weak var txtvalor2: UITextField!
    @IBOutlet weak var lblresultado: UILabel!

    @IBOutlet weak var btncalcular: UIButton!
    @IBOutlet weak var segopciones: UISegmentedControl!
    @IBOutlet weak var btnsegmento: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func calcular(_ sender: UIButton) {
        var vl_valor1:String=""
        var vl_valor2:String=""
        var vl_resultado:Double=0.0
        var opcionselec:Int=0
        vl_valor1=txtvalor1.text!
        vl_valor2=txtvalor2.text!
        opcionselec=segopciones.selectedSegmentIndex
        
        //Suma
        if opcionselec==0{
            vl_resultado = Double(vl_valor1)! + Double(vl_valor2)!
        }
        
        //Resta
        if opcionselec==1{
            vl_resultado = Double(vl_valor1)! - Double(vl_valor2)!
        }
        
        //Multiplicacion
        if opcionselec==2{
            vl_resultado = Double(vl_valor1)! * Double(vl_valor2)!
        }
        
        //Division
        if opcionselec==3{
            vl_resultado = Double(vl_valor1)! / Double(vl_valor2)!
        }
        
        lblresultado.text=String(vl_resultado)
    }
}

