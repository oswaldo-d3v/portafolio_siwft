//
//  ViewController.swift
//  clase20211009b
//
//  Created by Development on 10/9/21.
//  Copyright © 2021 Development. All rights reserved.
//

import UIKit


class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var txtSalario: UITextField!
    @IBOutlet weak var pickerPago: UIPickerView!
    @IBOutlet weak var lblImpuesto: UILabel!
    @IBOutlet weak var lblopcion: UILabel!
    
    var objimpuestoRenta=impuestoRenta()
    
    let pickerData = ["Mensual", "Quincenal", "Semanal" ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        pickerPago.dataSource=self
        pickerPago.delegate=self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func calcularImpuesto(_ sender: UIButton) {
        var resultado:Double=0.00
        var vsalarioD:Double=0.00
        var vopcion:String=""
        var vsalario:String=""
        vsalario=txtSalario.text!
        vsalarioD=Double(vsalario)!
        //var vsalario:NSString=""
        //vsalario=txtSalario.text as! NSString
        vopcion=lblopcion.text!
        
        
        if vopcion == "Mensual"{
            resultado=objimpuestoRenta.Mensual(pvalor: vsalarioD)
        }
        
        if vopcion == "Quincenal"{
            resultado=objimpuestoRenta.Quincenal(pvalor: vsalarioD)
        }
        
        if vopcion == "Semanal"{
            resultado=objimpuestoRenta.Semanal(pvalor: vsalarioD)
        }
        lblImpuesto.text = String(resultado)
        //resultado=objimpuestoRenta.
    }
    
    
    //MARK:Datasources
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        lblopcion.text = pickerData[row]
    }
    
}

