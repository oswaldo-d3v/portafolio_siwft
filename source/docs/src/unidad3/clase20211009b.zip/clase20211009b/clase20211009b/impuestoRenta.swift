////
// Nombre: Garcia Rosales, Zaira Ivonne
// Carnet: 25-1891-2017
//
//  impuestoRenta.swift
//  clase20211009b
//
//  Created by Development on 10/9/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation
// Metodo para calculo de renta
// para Mensual
// para Quincenal
// para Semanal

class impuestoRenta {

    func Semanal(pvalor:Double) -> Double{
        var impuesto:Double=0.00
        if(pvalor >= 0.01 && pvalor <= 118.00){
            impuesto=0.00
        }
        if(pvalor >= 118.01 && pvalor <= 223.81){
            impuesto=((pvalor - 118.00) * 0.10) + 4.42
        }
        if(pvalor >= 223.82 && pvalor <= 509.52){
            impuesto=((pvalor - 223.81) * 0.20) + 15.00
        }
        if(pvalor >= 509.53){
            impuesto=((pvalor - 509.52) * 0.30) + 72.14
        }
        return impuesto
    }

    func Quincenal(pvalor:Double) -> Double{
        var impuesto:Double=0.00
        if(pvalor >= 0.01 && pvalor <= 236.00){
            impuesto=0.00
        }
        if(pvalor >= 236.01 && pvalor <= 447.62){
            impuesto=((pvalor - 236.00) * 0.10) + 8.83
        }
        if(pvalor >= 447.63 && pvalor <= 1019.05){
            impuesto=((pvalor - 447.62) * 0.20) + 30.00
        }
        if(pvalor >= 1019.06){
            impuesto=((pvalor - 1019.05) * 0.30) + 144.28
        }
        return impuesto
    }

    func Mensual(pvalor:Double) -> Double{
        var impuesto:Double=0.00
        if(pvalor >= 0.01 && pvalor <= 472.00){
            impuesto=0.00
        }
        if(pvalor >= 472.01 && pvalor <= 895.24){
            impuesto=((pvalor - 472.00) * 0.10) + 17.67
        }
        if(pvalor >= 895.25 && pvalor <= 2038.10){
            impuesto=((pvalor - 895.24) * 0.20) + 60.00
        }
        if(pvalor >= 2038.11){
            impuesto=((pvalor - 2038.10) * 0.30) + 288.57
        }
        return impuesto
    }
}
