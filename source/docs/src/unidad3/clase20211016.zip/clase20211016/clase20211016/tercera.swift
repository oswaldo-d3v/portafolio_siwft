//
//  tercera.swift
//  clase20211016
//
//  Created by Development on 10/16/21.
//  Copyright © 2021 Development. All rights reserved.
//

import UIKit

class tercera: UIViewController {

    @IBOutlet weak var lbletiqueta3: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        lbletiqueta3.text="Ventana 3"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
