//
//  ViewController.swift
//  clase20211016b
//
//  Created by Development on 10/16/21.
//  Copyright © 2021 Development. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var txtnombre: UITextField!
    
    var dato2:String="None"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        txtnombre.text=dato2    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let viewController2 = segue.destination as! ViewController2
        viewController2.dato1 = txtnombre.text!
    }

}

