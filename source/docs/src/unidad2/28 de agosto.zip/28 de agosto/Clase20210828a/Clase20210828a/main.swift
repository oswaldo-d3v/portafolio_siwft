//
//  main.swift
//  Clase20210828a
//
//  Created by Development on 8/28/21.
//  Copyright © 2021 Development. All rights reserved.
//
/*
 Hecho por:
 Carnet: 
 Fecha: Agosto 28, 2021
*/

import Foundation

print("Hello, World!")

//Definir variables e imprimir resultado
var val1 = 0
var val2 = 5
var resultado = val1 + val2

print("Resultado de la operacion: \(resultado)")

if val2==5 {
    print("Es un valor de cinco")
}

var venta = 600 + val1 + val2 + val1 + val2



