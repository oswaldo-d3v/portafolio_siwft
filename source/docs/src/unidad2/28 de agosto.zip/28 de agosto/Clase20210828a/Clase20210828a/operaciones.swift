//
//  operaciones.swift
//  Clase20210828a
//
//  Created by Development on 8/28/21.
//  Copyright © 2021 Development. All rights reserved.
//
/*
import Foundation

/*
 Elaborar un programa que calcule una comision por valor de venta.
 Tabla de comision
 
 Monto Venta                % S/M. Venta
 0  a 300.99................... 2
 301  a 500.99................... 3
 501  a 750.99................... 3.5
 751  a 999.99................... 4
 1000 a mas...................... 4.5
 
 */

var ventaO:Double = 175.45
var comision:Double = 0.00
var porc:Double = 0.00


if ventaO<=300.99 {
    porc=0.02
}

if ventaO>=301 && ventaO<=500.99 {
    porc=0.03
}

if ventaO>=501 && ventaO<=750.99 {
    porc=0.035
}

if ventaO>=751 && ventaO<=999.99 {
    porc=0.04
}

if ventaO>=1000 {
    porc=0.045
}


comision = ventaO * porc

print("Por una venta de $\(ventaO) la comision es: $\(comision)")*/
