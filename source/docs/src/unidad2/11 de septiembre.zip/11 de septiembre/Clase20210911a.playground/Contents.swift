//: Playground - noun: a place where people can play
/*
 Nombre:
 Carnet:
 Fecha:
*/

import UIKit

var str = "Hello, playground"
//Definimos una clase para calculo

class calculo {
    //Definimos las propiedades
    var v1:Int = 5
    var v2:Int = 0
    var error:String = ""
    
    func sumar() -> Int {
        var resultado:Int = 0
        resultado = v1 + v2
        return resultado
    }
    
    func restar() -> Int {
        var resultado:Int = 0
        resultado = v1 - v2
        return resultado
    }
    
    func multiplicar() -> Int {
        var resultado:Int = 0
        resultado = v1 * v2
        return resultado
    }
    
    func dividir() -> Double {
        var resultado:Double = 0
        if (v2 != 0){
            resultado = Double(v1) / Double(v2)
        } else {
            error="Error: No se puede dividir entre 0"
            resultado = -1
        }
        return resultado
    }
    
}

var objcalculo:calculo=calculo()
objcalculo.v1=4
objcalculo.v2=5
objcalculo.sumar()
objcalculo.restar()
objcalculo.multiplicar()
objcalculo.dividir()
objcalculo.error

var objcalculo1:calculo=calculo()
objcalculo1.v1=6
objcalculo1.v2=0
objcalculo1.sumar()
objcalculo1.dividir()
objcalculo1.error

var a:Int = 5
var b:Double = 1.2
var c:Float = 2.75
var d:String = "4.5"


var x:Int = 0
var y:Double = 0
var z:Float = 0

//Conversiones para enteros
x = Int(b);
x = Int(c)
x = (d as NSString).integerValue

//Conversiones para double
y = Double(a);
y = Double(c)
y = (d as NSString).doubleValue

//Conversiones para float
z = (d as NSString).floatValue
