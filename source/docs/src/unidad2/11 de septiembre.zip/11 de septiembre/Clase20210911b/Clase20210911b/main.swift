//
//  main.swift
//  Clase20210911b
//
//  Created by Development on 9/11/21.
//  Copyright © 2021 Development. All rights reserved.
//
/*
 Nombre:
 Carnet: 
 Fecha : Septiembre 11, 2021
*/

import Foundation

var objcalculo:calculo=calculo()
objcalculo.v1 = 5
objcalculo.v2 = 0
print(objcalculo.sumar())
print(objcalculo.restar())
print(objcalculo.multiplicar())
print(objcalculo.dividir())
print(objcalculo.error)

var objcustomer:customer=customer()
objcustomer.city = "San Salvador"
print(objcustomer.city)

