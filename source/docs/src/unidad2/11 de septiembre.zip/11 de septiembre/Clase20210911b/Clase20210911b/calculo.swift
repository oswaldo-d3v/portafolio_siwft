//
//  calculo.swift
//  Clase20210911b
//
//  Created by Development on 9/11/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation
class calculo {
    //Definimos las propiedades
    var v1:Int = 0
    var v2:Int = 0
    var error:String = ""
    
    func sumar() -> Int {
        var resultado:Int = 0
        resultado = v1 + v2
        return resultado
    }
    
    func restar() -> Int {
        var resultado:Int = 0
        resultado = v1 - v2
        return resultado
    }
    
    func multiplicar() -> Int {
        var resultado:Int = 0
        resultado = v1 * v2
        return resultado
    }
    
    func dividir() -> Double {
        var resultado:Double = 0
        if (v2 != 0){
            resultado = Double(v1) / Double(v2)
        } else {
            error="Error: No se puede dividir entre 0"
            resultado = -1
        }
        return resultado
    }
}

class customer {
    
    var firsName = ""
    var lastName = ""
    var addressLine1 = ""
    var addressLine2 = ""
    var city = ""
    var state = ""
    var zip = ""
    var phoneNumber = ""
    var emailAddress = ""
    var favoriteGenre = ""
    
}
