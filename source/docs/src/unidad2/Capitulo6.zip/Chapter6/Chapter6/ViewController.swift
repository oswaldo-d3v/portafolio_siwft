//
//  ViewController.swift
//  Chapter6
//
//  Created by Development on 10/20/21.
//  Copyright © 2021 Development. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    
    @IBAction func showName(_ sender: UIButton) {
        nameLabel.text = "My Name is Brad"
    }
    
    
    @IBOutlet weak var label2: UILabel!
    
    @IBAction func newButton(_ sender: UIButton) {
        label2.text = "Hola Mundo"
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

