//
//  BookStore.swift
//  BookStore
//
//  Created by Development on 10/26/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation

class BookStore {
    var Name = ""
    var Address1 = ""
    var Address2 = ""
    var City = ""
    var State = ""
    var Zip = ""
    var PhoneNumber = ""
    var Logo = ""
}
