//
//  Scale.swift
//  BookStore
//
//  Created by Development on 10/26/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation

class Sale {
    var Custumer = ""
    var Book = ""
    var Date = ""
    var Time = ""
    var Amount = ""
    var PaymentType = ""
}
