//
//  Book.swift
//  BookStore
//
//  Created by Development on 10/26/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation

class Book {
    var Autor = ""
    var Publisher = ""
    var Genre = ""
    var YearPublished = ""
    var NumberOfPages = ""
    var Edition = ""
    var Price = ""
}
