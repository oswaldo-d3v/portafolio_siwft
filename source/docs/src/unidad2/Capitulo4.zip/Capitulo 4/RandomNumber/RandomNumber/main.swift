//
//  main.swift
//  RandomNumber
//
//  Created by Development on 10/23/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation

var randomNumber = 1
var continueGuessing = true
var keepPlaying = true
var input = ""

var intentos = 0
var partidas = 0

while keepPlaying {
    partidas = partidas + 1
    randomNumber = Int(arc4random_uniform(101))
    print("El numero aleatorio es: \(randomNumber)")
    while continueGuessing {
        print("Adivina el numero entre 0 y 100: ")
        input = NSString(data: FileHandle.standardInput.availableData, encoding: String.Encoding.utf8.rawValue)! as String
        input = input.replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range: nil)
        if let userGuess = Int(input) {
            intentos = intentos + 1
            if userGuess == randomNumber {
                continueGuessing = false
                print("Correcto!")
                print("Numero de intentos \(intentos)")
                intentos = 0
            } else if userGuess < randomNumber {
                print("Es un numero mayor")
            } else {
                print("Es un numero menor")
            }
            
        } else {
            print("El valor ingresado no es valido")
        }
    }
    
    print("Seguir jugando? S/N")
    input = NSString(data: FileHandle.standardInput.availableData, encoding: String.Encoding.utf8.rawValue)! as String
    input = input.replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range: nil)
    
    if input == "N" || input == "n" {
        keepPlaying = false
        print("Partidas jugadas \(partidas)")
    }
    continueGuessing = true
}
