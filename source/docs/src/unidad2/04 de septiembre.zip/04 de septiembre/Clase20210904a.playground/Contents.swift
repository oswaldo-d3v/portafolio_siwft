//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

func getPhrase() -> String {
    return "Hola desde una funcion"
}

print(getPhrase())

func imprimirmensaje(){
    print("Funcion imprime mensaje")
}

imprimirmensaje()

func sumar(num1:Int, num2:Int) -> Int {
    var resultado = 0
    resultado = num1 + num2
    return resultado
}

var lasuma:Int = 0
lasuma = sumar(num1: 5, num2: 8)
print("El resultado de la suma es: \(lasuma)")
