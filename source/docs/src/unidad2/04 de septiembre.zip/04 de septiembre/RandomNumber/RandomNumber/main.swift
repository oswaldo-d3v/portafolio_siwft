//
//  main.swift
//  RandomNumber
//
//
/* Nombre: Miguel Oswaldo Escbar Cuellar
   Carnet: 25-0729-2017
   Fecha : Septiembre 4, 2021  */
/*
 Ejercicio: Mejorar programa de libro de texto de nombre RandomNumber, incorporando una funcion para leer, desde teclado lo ingresado por el usuario, reduciendo asi numero de lineas y ootimizando asi como reutilizando codigo, es de criterio de los participantes, incorporar parametros asi como retorno de dato, en la definicion de la funcion
 */

import Foundation


var randomNumber = 1
var continueGuessing = true
var keepPlaying = true
var input = ""

func capturaUsuario() -> String
{
    input = NSString(data: FileHandle.standardInput.availableData, encoding: String.Encoding.utf8.rawValue)! as String
    input = input.replacingOccurrences(of: "\n", with: "")
    return input
}

while keepPlaying {
    randomNumber = Int(arc4random_uniform(101))
    print("The random number to guess is: \(randomNumber)")
    while continueGuessing {
        print("Pick a number between 0 and 100.")
        input = capturaUsuario()
        if let userGuess = Int(input){
            if userGuess >= 0 && userGuess <= 100 {
                if userGuess == randomNumber {
                    continueGuessing = false
                    print("Correct number!")
                }
                else if userGuess > randomNumber {
                    print ("Your guess is too high!")
                }
                else {
                    print("Your guess is too low!")
                }
            }
            else {
                print ("No esta en el rango")
            }
        }
        else {
            print("Invalid guess, plese try again.")
        }
    }

    print("Play Again? Y or N")
    input = capturaUsuario()
    
    if input == "N" || input == "n" {
        keepPlaying = false
    }
    continueGuessing = true

}
