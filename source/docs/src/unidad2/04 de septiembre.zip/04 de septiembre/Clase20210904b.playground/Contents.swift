//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var a3 = ["A", "B", "C"]
a3.count
var a2:[String] = [String]()
a2.count
var a1:Array<String> = Array<String>()
a1.count

a1.append("Limones")
a1.append("Naranjas")
a1.append("Mandarinas")
a1.count
a2.append("Nissan")
a2.append("Toyota")
a2.append("Mahindra")
a2.count
a1.insert("Limas", at: 1)

a1[2]

for fruta in a1 {
    print(fruta)
}

a2.remove(at: 2)
a2.append("Isuzu")
a2
